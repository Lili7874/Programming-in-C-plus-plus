//---------------------------------------------------------------------------

#include <fmx.h>
#include <fstream>
#pragma hdrstop

#include "RegistrationForm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TMyRegistrationForm *MyRegistrationForm;
//---------------------------------------------------------------------------
__fastcall TMyRegistrationForm::TMyRegistrationForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMyRegistrationForm::SaveButtonClickClick(TObject *Sender)
{
// otwieranie pliku txt i rozpoczecie pracy na nim
		fstream myFile;
		myFile.open("registeredUsers.txt",ios::app);
		if(myFile.is_open()){

		//pobieranie inputu uzytkownika do zmiennych login i password

			AnsiString login = loginEdit->Text;
			AnsiString password = passwordEdit->Text;

		//uzupelnienie pliku tekstowego danymi o nowym userze w odpowiednim formacie

			myFile<<login<<","<<password<<"\n";
			myFile.close();
			this->Close();
		}
}
//---------------------------------------------------------------------------
