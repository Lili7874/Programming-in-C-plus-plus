//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop
#include <FireDAC.DApt.hpp>
#include "Base.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TMyBase *MyBase;
//---------------------------------------------------------------------------
__fastcall TMyBase::TMyBase(TComponent* Owner)
	: TForm(Owner)
{


};
//---------------------------------------------------------------------------
void __fastcall TMyBase::SearchButtonClick(TObject *Sender)
{
				FDQuery2->Close();


				FDQuery2 -> ParamByName("inputPlec")->Value= plecWybor->Items->Strings[plecWybor->ItemIndex];
				FDQuery2 -> ParamByName("inputColWlos")->Value= ColWlosowWybor->Items->Strings[ColWlosowWybor->ItemIndex];
				FDQuery2 -> ParamByName("inputColOcz")->Value= ColOczuWybor->Items->Strings[ColOczuWybor->ItemIndex];;
				FDQuery2 -> ParamByName("inputTyp")->Value= TypWybor->Items->Strings[TypWybor->ItemIndex];;

				FDQuery2->Open();

}
//---------------------------------------------------------------------------
