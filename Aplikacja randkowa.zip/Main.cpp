//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "Main.h"
#include "LoginForm.h"
#include "RegistrationForm.h"
#include "Base.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TMyMainForm *MyMainForm;
//---------------------------------------------------------------------------
__fastcall TMyMainForm::TMyMainForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
// Otwieranie okna rejestracji lub logowania po kliknieciu w guzik
void __fastcall TMyMainForm::registrationNavigationButtonClick(TObject *Sender)
{

	MyRegistrationForm->Show();
}
//---------------------------------------------------------------------------
void __fastcall TMyMainForm::loginNavigationButtonClick(TObject *Sender)
{
	MyLoginForm->Show();
}
//---------------------------------------------------------------------------
