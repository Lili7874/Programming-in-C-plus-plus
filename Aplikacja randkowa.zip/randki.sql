-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Maj 28, 2023 at 03:48 AM
-- Wersja serwera: 10.4.28-MariaDB
-- Wersja PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `randki`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `kandydaci`
--

CREATE TABLE `kandydaci` (
  `Id` int(3) NOT NULL,
  `płeć` text NOT NULL DEFAULT 'mężczyzna',
  `imie` text NOT NULL,
  `nazwisko` text NOT NULL,
  `miejscowosc` text NOT NULL DEFAULT 'Warszawa',
  `numer_telefonu` int(9) NOT NULL DEFAULT 777777777,
  `wzrost` float NOT NULL DEFAULT 175,
  `wiek` int(2) NOT NULL DEFAULT 22,
  `kolor_wlosow` text NOT NULL DEFAULT 'czarny',
  `kolor_oczu` text NOT NULL DEFAULT 'brązowy',
  `kolor_skory` text NOT NULL DEFAULT 'biały',
  `typ_osobowosci` text NOT NULL DEFAULT 'ekstrawertyczny'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `kandydaci`
--

INSERT INTO `kandydaci` (`Id`, `płeć`, `imie`, `nazwisko`, `miejscowosc`, `numer_telefonu`, `wzrost`, `wiek`, `kolor_wlosow`, `kolor_oczu`, `kolor_skory`, `typ_osobowosci`) VALUES
(1, 'mężczyzna', 'Eustachy', 'Pawlak', 'Radom', 751311342, 178, 29, 'czarny', 'brązowy', 'biały', 'ekstrawertyczny'),
(2, 'mężczyzna', 'Ignacy', 'Kalinowski', 'Opole', 745527844, 184, 26, 'blond', 'niebieski', 'biały', 'intorwertyczny'),
(3, 'mężczyzna', 'Ryszard', 'Czarnecki', 'Ruda Śląska', 834843876, 174, 34, 'brązowy', 'zielony', 'biały', 'ekstrawertyczny'),
(4, 'mężczyzna', 'Ksawery', 'Lis', 'Gdańsk', 777627083, 187, 22, 'blond', 'niebieski', 'biały', 'intorwertyczny'),
(5, 'mężczyzna', 'Aureliusz', 'Błaszczyk', 'Lublin', 857256051, 175, 24, 'brązowy', 'brązowy', 'biały', 'ekstrawertyczny'),
(6, 'mężczyzna', 'Fabian', 'Krawczyk', 'Katowice', 808680507, 179, 23, 'blond', 'zielony', 'biały', 'intorwertyczny'),
(7, 'mężczyzna', 'Marcin', 'Nowak', 'Kielce', 821511683, 178, 30, 'czarny', 'brązowy', 'biały', 'ekstrawertyczny'),
(8, 'mężczyzna', 'Oskar', 'Sawicki', 'Gdańsk', 819928434, 181, 20, 'czarny', 'niebieski', 'biały', 'intorwertyczny'),
(9, 'mężczyzna', 'Karol', 'Rutkowski', 'Kraków', 804504420, 177, 24, 'czarny', 'brązowy', 'biały', 'ekstrawertyczny'),
(10, 'mężczyzna', 'Alan', 'Sobczak', 'Wrocław', 760664643, 179, 27, 'czarny', 'brązowy', 'biały', 'ekstrawertyczny'),
(11, 'mężczyzna', 'Dawid', 'Włodarczyk', 'Poznań', 761452086, 180, 22, 'blond', 'niebieski', 'biały', 'intorwertyczny'),
(12, 'mężczyzna', 'Maksymilian', 'Szewczyk', 'Kraków', 786056161, 184, 26, 'czarny', 'brązowy', 'biały', 'intorwertyczny'),
(13, 'mężczyzna', 'Janusz', 'Szymański', 'Gdańsk', 849489579, 187, 31, 'czarny', 'brązowy', 'biały', 'ekstrawertyczny'),
(14, 'mężczyzna', 'Jan', 'Wójcik', 'Warszawa', 752586230, 190, 18, 'brązowy', 'brązowy', 'biały', 'ekstrawertyczny'),
(15, 'mężczyzna', 'Ernest', 'Chmielewski', 'Kraków', 736480022, 176, 20, 'czarny', 'brązowy', 'biały', 'intorwertyczny'),
(16, 'mężczyzna', 'Przemysław', 'Wojciechowski', 'Szczecin', 719999095, 179, 24, 'brązowy', 'niebieski', 'biały', 'amabylilczny'),
(17, 'mężczyzna', 'Kordian', 'Kucharski', 'Łódź', 799474023, 184, 29, 'brązowy', 'brązowy', 'biały', 'ekstrawertyczny'),
(18, 'mężczyzna', 'Florian', 'Sobczak', 'Szczecin', 730660459, 180, 22, 'czarny', 'niebieski', 'biały', 'ekstrawertyczny'),
(19, 'mężczyzna', 'Kuba', 'Baran', 'Łódź', 885447654, 177, 23, 'blond', 'zielony', 'biały', 'ekstrawertyczny'),
(20, 'mężczyzna', 'Kamil', 'Michalak', 'Kraków', 799201742, 183, 19, 'czarny', 'brązowy', 'biały', 'neurotyczny'),
(21, 'mężczyzna', 'Błażej', 'Kozłowski', 'Warszawa', 748492563, 178, 28, 'czarny', 'niebieski', 'biały', 'intorwertyczny'),
(22, 'mężczyzna', 'Marcel', 'Walczak', 'Kraków', 719016422, 178, 20, 'blond', 'brązowy', 'biały', 'ekstrawertyczny'),
(23, 'mężczyzna', 'Krzysztof', 'Zakrzewski', 'Warszawa', 756933651, 186, 24, 'brązowy', 'zielony', 'biały', 'ekstrawertyczny'),
(24, 'mężczyzna', 'Paweł', 'Jaworski', 'Rzeszów', 831289881, 182, 32, 'czarny', 'brązowy', 'biały', 'amabylilczny'),
(25, 'mężczyzna', 'Oskar', 'Sokołowski', 'Bytom', 722374681, 184, 18, 'brązowy', 'niebieski', 'biały', 'ekstrawertyczny'),
(26, 'mężczyzna', 'Andrzej', 'Ostrowski', 'Warszawa', 829607346, 177, 21, 'blond', 'brązowy', 'biały', 'ekstrawertyczny'),
(27, 'mężczyzna', 'Roman', 'Baran', 'Zabrze', 818772311, 180, 29, 'blond', 'zielony', 'biały', 'intorwertyczny'),
(28, 'mężczyzna', 'Grzegorz', 'Czerwiński', 'Rybnik', 842224594, 176, 19, 'czarny', 'brązowy', 'biały', 'ekstrawertyczny'),
(29, 'mężczyzna', 'Ignacy', 'Mróz', 'Warszawa', 791710719, 174, 23, 'brązowy', 'niebieski', 'biały', 'neurotyczny'),
(30, 'mężczyzna', 'Hubert', 'Wysocki', 'Kraków', 825429176, 192, 27, 'czarny', 'niebieski', 'biały', 'intorwertyczny'),
(31, 'mężczyzna', 'Jerzy', 'Szulc', 'Rzeszów', 733049449, 168, 22, 'blond', 'brązowy', 'biały', 'ekstrawertyczny'),
(32, 'mężczyzna', 'Kuba', 'Górski', 'Gliwice', 769339239, 178, 18, 'blond', 'brązowy', 'biały', 'ekstrawertyczny'),
(33, 'mężczyzna', 'Marcin', 'Cieślak', 'Sosnowiec', 787549971, 176, 33, 'czarny', 'niebieski', 'biały', 'ekstrawertyczny'),
(34, 'mężczyzna', 'Albert', 'Kołodziej', 'Bydgoszcz', 742885632, 189, 26, 'blond', 'brązowy', 'biały', 'ekstrawertyczny'),
(35, 'mężczyzna', 'Florian', 'Malinowski', 'Tychy', 837592768, 184, 24, 'brązowy', 'niebieski', 'biały', 'amabylilczny'),
(36, 'mężczyzna', 'Michał', 'Witkowski', 'Kraków', 881177043, 185, 28, 'czarny', 'zielony', 'biały', 'ekstrawertyczny'),
(37, 'mężczyzna', 'Ireneusz', 'Kwiatkowski', 'Sosnowiec', 748091069, 169, 23, 'blond', 'brązowy', 'biały', 'ekstrawertyczny'),
(38, 'mężczyzna', 'Krzysztof', 'Kubiak', 'Kraków', 824279375, 185, 20, 'brązowy', 'niebieski', 'biały', 'ekstrawertyczny'),
(39, 'mężczyzna', 'Patryk', 'Szymański', 'Gliwice', 710600541, 183, 31, 'czarny', 'brązowy', 'biały', 'neurotyczny'),
(40, 'mężczyzna', 'Oskar', 'Piotrowski', 'Tychy', 760492274, 173, 19, 'brązowy', 'zielony', 'biały', 'ekstrawertyczny'),
(41, 'kobieta', 'Daria', 'Górska', 'Warszawa', 765349895, 167, 21, 'brązowy', 'brązowy', 'biały', 'ekstrawertyczny'),
(42, 'kobieta', 'Sylwia', 'Makowska', 'Kraków', 848715301, 172, 18, 'czarny', 'niebieski', 'biały', 'ekstrawertyczny'),
(43, 'kobieta', 'Zuzanna', 'Krawczyk', 'Łódź', 704444010, 164, 26, 'blond', 'brązowy', 'biały', 'intorwertyczny'),
(44, 'kobieta', 'Wioletta', 'Kwiatkowska', 'Warszawa', 777913303, 163, 30, 'brązowy', 'zielony', 'biały', 'amabylilczny'),
(45, 'kobieta', 'Luiza', 'Wójcik', 'Kraków', 766657175, 159, 25, 'blond', 'niebieski', 'biały', 'intorwertyczny'),
(46, 'kobieta', 'Aleksandra', 'Kowalska', 'Warszawa', 720177705, 160, 24, 'blond', 'brązowy', 'biały', 'ekstrawertyczny'),
(47, 'kobieta', 'Żaneta', 'Szymczak', 'Wrocław', 718382693, 157, 23, 'czarny', 'zielony', 'biały', 'intorwertyczny'),
(48, 'kobieta', 'Paulina', 'Piotrowska', 'Kraków', 745633325, 168, 27, 'czarny', 'brązowy', 'biały', 'amabylilczny'),
(49, 'kobieta', 'Aniela', 'Laskowska', 'Warszawa', 707008158, 170, 19, 'brązowy', 'niebieski', 'biały', 'ekstrawertyczny'),
(50, 'kobieta', 'Oktawia', 'Kowalska', 'Gliwice', 792259113, 173, 31, 'blond', 'niebieski', 'biały', 'intorwertyczny'),
(51, 'kobieta', 'Kornelia', 'Kołodziej', 'Kraków', 818229098, 176, 29, 'czarny', 'brązowy', 'biały', 'ekstrawertyczny'),
(52, 'kobieta', 'Alina', 'Duda', 'Warszawa', 774238603, 165, 24, 'czarny', 'zielony', 'biały', 'neurotyczny'),
(53, 'kobieta', 'Katarzyna', 'Borkowska', 'Wrocław', 737617948, 166, 18, 'czarny', 'brązowy', 'biały', 'ekstrawertyczny'),
(54, 'kobieta', 'Blanka', 'Krajewska', 'Warszawa', 739347475, 160, 22, 'brązowy', 'brązowy', 'biały', 'ekstrawertyczny'),
(55, 'kobieta', 'Aneta', 'Brzezińska', 'Lublin', 869999915, 156, 32, 'czarny', 'niebieski', 'biały', 'intorwertyczny'),
(56, 'kobieta', 'Angelika', 'Urbańska', 'Łódź', 880266062, 170, 27, 'brązowy', 'brązowy', 'biały', 'ekstrawertyczny'),
(57, 'kobieta', 'Julia', 'Pawlak', 'Poznań', 729872526, 162, 26, 'czarny', 'zielony', 'biały', 'neurotyczny'),
(58, 'kobieta', 'Oktawia', 'Wysocka', 'Poznań', 751718839, 167, 19, 'czarny', 'niebieski', 'biały', 'ekstrawertyczny'),
(59, 'kobieta', 'Agata', 'Sokołowska', 'Lublin', 798553202, 164, 23, 'brązowy', 'brązowy', 'biały', 'intorwertyczny'),
(60, 'kobieta', 'Kaja', 'Kowalczyk', 'Warszawa', 887318046, 163, 21, 'blond', 'niebieski', 'biały', 'ekstrawertyczny'),
(61, 'kobieta', 'Weronika', 'Mazurek', 'Łódź', 705578761, 169, 28, 'blond', 'brązowy', 'biały', 'amabylilczny'),
(62, 'kobieta', 'Ewelina', 'Sadowska', 'Szczecin', 807087826, 175, 30, 'czarny', 'zielony', 'biały', 'ekstrawertyczny'),
(63, 'kobieta', 'Wiktoria', 'Szewczyk', 'Warszawa', 858816624, 163, 24, 'brązowy', 'brązowy', 'biały', 'intorwertyczny'),
(64, 'kobieta', 'Liliana', 'Kalinowska', 'Białystok', 777831097, 158, 21, 'czarny', 'niebieski', 'biały', 'intorwertyczny'),
(65, 'kobieta', 'Magdalena', 'Sikorska', 'Poznań', 744725030, 168, 20, 'brązowy', 'niebieski', 'biały', 'ekstrawertyczny'),
(66, 'kobieta', 'Magda', 'Dąbrowska', 'Szczecin', 771590974, 166, 18, 'blond', 'brązowy', 'biały', 'intorwertyczny'),
(67, 'kobieta', 'Emilia', 'Wysocka', 'Warszawa', 859248246, 161, 18, 'brązowy', 'zielony', 'biały', 'ekstrawertyczny'),
(68, 'kobieta', 'Patrycja', 'Kwiatkowska', 'Sosnowiec', 792687674, 157, 22, 'czarny', 'niebieski', 'biały', 'ekstrawertyczny'),
(69, 'kobieta', 'Asia', 'Andrzejewska', 'Katowice', 777646854, 163, 29, 'czarny', 'brązowy', 'biały', 'intorwertyczny'),
(70, 'kobieta', 'Gabriela', 'Zawadzka', 'Gdynia', 777009211, 173, 24, 'blond', 'niebieski', 'biały', 'intorwertyczny'),
(71, 'kobieta', 'Izabela', 'Marciniak', 'Katowice', 819286769, 162, 20, 'brązowy', 'niebieski', 'biały', 'ekstrawertyczny'),
(72, 'kobieta', 'Martyna', 'Lewandowska', 'Katowice', 852566394, 156, 26, 'czarny', 'brązowy', 'biały', 'amabylilczny'),
(73, 'kobieta', 'Oliwia', 'Jaworska', 'Kielce', 770654134, 175, 28, 'brązowy', 'brązowy', 'biały', 'ekstrawertyczny'),
(74, 'kobieta', 'Zuzanna', 'Górecka', 'Częstochowa', 833424740, 166, 21, 'czarny', 'niebieski', 'biały', 'intorwertyczny'),
(75, 'kobieta', 'Ewa', 'Przybylska', 'Katowice', 857802525, 169, 23, 'blond', 'brązowy', 'biały', 'neurotyczny'),
(76, 'kobieta', 'Marta', 'Andrzejewska', 'Radom', 833363262, 162, 19, 'czarny', 'brązowy', 'biały', 'ekstrawertyczny'),
(77, 'kobieta', 'Weronika', 'Adamska', 'Gdynia', 884032501, 160, 27, 'blond', 'niebieski', 'biały', 'intorwertyczny'),
(78, 'kobieta', 'Amelia', 'Kamińska', 'Częstochowa', 736939693, 164, 22, 'blond', 'zielony', 'biały', 'ekstrawertyczny'),
(79, 'kobieta', 'Julia', 'Wiśniewska', 'Kraków', 779774141, 162, 20, 'brązowy', 'zielony', 'biały', 'intorwertyczny'),
(80, 'kobieta', 'Nikola', 'Jankowska', 'Katowice', 716581990, 159, 18, 'blond', 'niebieski', 'biały', 'intorwertyczny');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `kandydaci`
--
ALTER TABLE `kandydaci`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kandydaci`
--
ALTER TABLE `kandydaci`
  MODIFY `Id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
