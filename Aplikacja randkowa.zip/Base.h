//---------------------------------------------------------------------------

#ifndef BaseH
#define BaseH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include <Data.Bind.Controls.hpp>
#include <Data.DB.hpp>
#include <Data.Win.ADODB.hpp>
#include <Fmx.Bind.Navigator.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.Grid.hpp>
#include <FMX.Grid.Style.hpp>
#include <FMX.Layouts.hpp>
#include <FMX.ScrollBox.hpp>
#include <FMX.Types.hpp>
#include <System.Rtti.hpp>
#include <Data.Bind.Components.hpp>
#include <Data.Bind.DBScope.hpp>
#include <Data.Bind.EngExt.hpp>
#include <Data.Bind.Grid.hpp>
#include <FireDAC.Comp.Client.hpp>
#include <FireDAC.Comp.DataSet.hpp>
#include <FireDAC.DApt.hpp>
#include <FireDAC.DApt.Intf.hpp>
#include <FireDAC.DatS.hpp>
#include <FireDAC.FMXUI.Wait.hpp>
#include <FireDAC.Phys.hpp>
#include <FireDAC.Phys.IB.hpp>
#include <FireDAC.Phys.IBDef.hpp>
#include <FireDAC.Phys.Intf.hpp>
#include <FireDAC.Stan.Async.hpp>
#include <FireDAC.Stan.Def.hpp>
#include <FireDAC.Stan.Error.hpp>
#include <FireDAC.Stan.Intf.hpp>
#include <FireDAC.Stan.Option.hpp>
#include <FireDAC.Stan.Param.hpp>
#include <FireDAC.Stan.Pool.hpp>
#include <FireDAC.UI.Intf.hpp>
#include <Fmx.Bind.DBEngExt.hpp>
#include <Fmx.Bind.Editors.hpp>
#include <Fmx.Bind.Grid.hpp>
#include <System.Bindings.Outputs.hpp>
#include <FMX.Edit.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.ListBox.hpp>
//---------------------------------------------------------------------------
class TMyBase : public TForm
{
__published:	// IDE-managed Components
	TGrid *Grid1;
	TFDQuery *KandydaciTable;
	TFDConnection *FDConnection1;
	TFDConnection *EmployeeConnection;
	TBindingsList *BindingsList1;
	TFDQuery *FDQuery2;
	TBindSourceDB *BindSourceDB2;
	TButton *SearchButton;
	TLinkGridToDataSource *LinkGridToDataSourceBindSourceDB2;
	TLabel *Plec;
	TLabel *Kolor_wlosow;
	TLabel *Label3;
	TLabel *Typ_osobo;
	TComboBox *plecWybor;
	TComboBox *ColWlosowWybor;
	TComboBox *ColOczuWybor;
	TComboBox *TypWybor;
	TListBoxItem *introwertyk;
	TListBoxItem *ListBoxItem6;
	TListBoxItem *ListBoxItem1;
	TListBoxItem *ListBoxItem3;
	TListBoxItem *ListBoxItem4;
	TListBoxItem *black;
	TListBoxItem *light;
	TListBoxItem *brown;
	TListBoxItem *Male;
	TListBoxItem *ListBoxItem2;
	TListBoxItem *ListBoxItem5;
	TListBoxItem *ListBoxItem7;
	void __fastcall SearchButtonClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TMyBase(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMyBase *MyBase;
//---------------------------------------------------------------------------
#endif
