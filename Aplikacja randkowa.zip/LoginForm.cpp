//---------------------------------------------------------------------------

#include <fmx.h>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#pragma hdrstop

#include "LoginForm.h"
#include "Base.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TMyLoginForm *MyLoginForm;
//---------------------------------------------------------------------------
__fastcall TMyLoginForm::TMyLoginForm(TComponent* Owner)
	: TForm(Owner)
{
}
std::vector<std::string> parseCommaDelimitedString(std:: string line){
	std::vector<std::string> result;
	std::stringstream s_stream(line);

	while(s_stream.good()){
	std::string substr;
	getline(s_stream,substr,',');
	result.push_back(substr);
	}
	return result;
}
//funkcja zamiany string na const char*, musi byc const poniewaz wskazuje na C-string ktory jest przez kompilator
//traktowany jakos const char*
const char* convertToCharPtr(AnsiString ansiStr){

	return ansiStr.c_str();
}

//---------------------------------------------------------------------------
void __fastcall TMyLoginForm::loginButtonClick(TObject *Sender)
{
// otwieranie pliku txt i rozpoczecie pracy na nim
		fstream myFile;
		myFile.open("registeredUsers.txt",ios::in);
		if(myFile.is_open()){

				//zmienna ktora posluzy do czytania linijek pliku tekstowego
				std::string line;

				//zmienna ktora pozwala na zarejestrowanie faktu podania prawidlowych, pasujacych do siebie danych
				bool loginCorrect = false;

				//petla while ktora zapetla proces sprawdzania poprawnosci danych, zatrzymuje sie na koncu pliku txt lub gdy
				// znaleziony zostanie odpowiedni login i haslo
				while(getline(myFile, line)&&loginCorrect==false) {

				//wektory usprawniajace rozpoznawanie poszczegolnych elementow linijki
				//cyfra 0 i 1 to indeksy elementow rozdzielonych przecinkami, pozwala to porownanie np ciagow znakow ze soba
				//po bardzo latwym wydzieleniu z nich hasla i loginu
				std::vector<std::string> parsedLine= parseCommaDelimitedString(line);

				//przypisanie do zmiennej login czesci linijki o indeksie 0
				const char* login=parsedLine.at(0).c_str();


				  //strcmp porownuje stringi, w tym przypadku porownuje zapisany w pliku txt login i wprowadzony przez
				  //uzytkownika text do pola wpisywania loginu (uzyta funkcja konwersji na char* zapisana wyzej)
				  //wynik porownania 0 oznacza ze obie zmienne sa rowne
					if(std::strcmp(login,convertToCharPtr(loginEdit->Text))==0){

					   const char* password=parsedLine.at(1).c_str();

					//porownanie hasel
						if(std::strcmp(password,convertToCharPtr(passwordEdit->Text))==0){

							messageLabel->Text = "Udane Logowanie";
							loginCorrect = true;
							MyLoginForm -> Close();
							MyBase->Show();
						}
						else{

							messageLabel->Text = "Nieudane Logowanie";
						}

					}
				}

			myFile.close();

		}
}
//---------------------------------------------------------------------------


